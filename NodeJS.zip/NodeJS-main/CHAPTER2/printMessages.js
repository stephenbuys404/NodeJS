"use strict"
const messageModule = require("./messages");
messageModule.messages.forEach(m => console.log(m))