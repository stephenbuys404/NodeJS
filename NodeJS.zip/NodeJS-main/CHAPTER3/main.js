"use strict";
const addModule = require("./addsum");
console.log(addModule.addNum(2,3));