"use strict";
exports.addNum = (x, y) => {
return x + y;
};